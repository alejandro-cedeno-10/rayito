"""Plano de control: puerto `ControlPlane` y adaptador boto3 `lambda-microvms`.

Todo parámetro enviado a AWS aparece literalmente en `AWS_API_NOTES.md` §2, §3,
§5 y §6. Los errores se mapean por **nombre** de excepción de botocore, nunca
por status HTTP (`ServiceQuotaExceededException` llega con 402).
"""

from __future__ import annotations

import re
import threading
import time
from collections.abc import Callable, Iterable, Iterator, Sequence
from dataclasses import dataclass, field
from typing import Any, Final, Protocol

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from rayito._account_setup._domain import with_setup_hint
from rayito._aws_region import aws_session, resolve_region
from rayito._aws_sanitize import AwsErrorSummary, redact_aws_text, sanitize_aws_error
from rayito._limits import (
    API_TPS,
    LIST_MAX_RESULTS,
    TERMINAL_STATES,
    TOKEN_TTL_MINUTES,
)
from rayito._models import (
    IdlePolicy,
    ImageVersionInfo,
    MicrovmListPage,
    SandboxInfo,
    SandboxListItem,
)
from rayito._version import __version__
from rayito.exceptions import (
    AuthenticationException,
    CapacityException,
    InvalidArgumentException,
    QuotaExceededException,
    RateLimitException,
    SandboxException,
    SandboxNotFoundException,
    SandboxStateException,
)

MonotonicClock = Callable[[], float]
Sleeper = Callable[[float], None]

AUTH_TOKEN_RESPONSE_KEY = "X-aws-proxy-auth"
IMAGE_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")


@dataclass(frozen=True)
class PortSpec:
    """Un `PortSpecification` de `create-microvm-auth-token`: puerto o rango.

    `allPorts` no se modela a propósito: expondría el puerto de hooks (ADR-006).
    """

    start: int
    end: int

    @classmethod
    def single(cls, port: int) -> PortSpec:
        return cls(port, port)

    @classmethod
    def range(cls, start: int, end: int) -> PortSpec:
        if start > end:
            raise InvalidArgumentException(f"rango de puertos invertido: {start}-{end}")
        return cls(start, end)

    def covers(self, port: int) -> bool:
        return self.start <= port <= self.end

    def to_api(self) -> dict[str, Any]:
        if self.start == self.end:
            return {"port": self.start}
        return {"range": {"startPort": self.start, "endPort": self.end}}


@dataclass(frozen=True)
class LaunchRequest:
    """`RunMicrovmRequest` ya validado. `idle` trae los tres campos resueltos.
    `run_hook_payload` lleva los `envs` de `create()` y queda fuera de
    `repr()`."""

    image_arn: str
    maximum_duration_seconds: int
    run_hook_payload: str = field(repr=False)
    client_token: str
    logging: dict[str, Any]
    image_version: str | None = None
    execution_role_arn: str | None = None
    idle: IdlePolicy | None = None
    ingress_connectors: tuple[str, ...] = ()
    egress_connectors: tuple[str, ...] = ()

    def to_api(self) -> dict[str, Any]:
        params: dict[str, Any] = {
            "imageIdentifier": self.image_arn,
            "maximumDurationInSeconds": self.maximum_duration_seconds,
            "runHookPayload": self.run_hook_payload,
            "clientToken": self.client_token,
            "logging": self.logging,
        }
        if self.image_version is not None:
            params["imageVersion"] = self.image_version
        if self.execution_role_arn is not None:
            params["executionRoleArn"] = self.execution_role_arn
        if self.idle is not None:
            params["idlePolicy"] = idle_policy_to_api(self.idle)
        if self.ingress_connectors:
            params["ingressNetworkConnectors"] = list(self.ingress_connectors)
        if self.egress_connectors:
            params["egressNetworkConnectors"] = list(self.egress_connectors)
        return params


class ControlPlane(Protocol):
    """Lo que el dominio necesita del plano de control de AWS."""

    @property
    def region(self) -> str: ...

    def resolve_template_arn(self, template: str) -> str: ...

    def run_microvm(self, request: LaunchRequest) -> SandboxInfo: ...

    def get_microvm(self, sandbox_id: str) -> SandboxInfo: ...

    def list_microvms(
        self,
        *,
        image_arn: str | None = None,
        image_version: str | None = None,
        states: Iterable[str] | None = None,
    ) -> Iterator[SandboxListItem]: ...

    def list_microvms_page(
        self,
        *,
        image_arn: str | None,
        image_version: str | None,
        max_results: int,
        next_token: str | None,
    ) -> MicrovmListPage: ...

    def terminate_microvm(self, sandbox_id: str) -> bool: ...

    def suspend_microvm(self, sandbox_id: str) -> bool: ...

    def resume_microvm(self, sandbox_id: str) -> bool: ...

    def create_auth_token(self, sandbox_id: str, ports: Sequence[PortSpec]) -> str: ...

    def get_microvm_image_version(self, image_arn: str, image_version: str) -> ImageVersionInfo: ...


class TokenBucket:
    """Limitador por operación alineado con la cuota publicada (burst = rate).

    Los tokens pueden quedar en negativo: cada `acquire` reserva su turno y
    duerme lo que falte, así N llamadas concurrentes se serializan al ritmo
    de la cuota sin que ninguna se pierda.
    """

    def __init__(
        self,
        rate_per_second: float,
        *,
        clock: MonotonicClock = time.monotonic,
        sleep: Sleeper = time.sleep,
    ) -> None:
        if rate_per_second <= 0:
            raise ValueError("rate_per_second debe ser > 0")
        self._rate = rate_per_second
        self._capacity = rate_per_second
        self._tokens = rate_per_second
        self._clock = clock
        self._sleep = sleep
        self._updated_at = clock()
        self._lock = threading.Lock()

    def acquire(self) -> float:
        with self._lock:
            self._refill()
            wait = max(0.0, (1.0 - self._tokens) / self._rate)
            self._tokens -= 1.0
        if wait > 0:
            self._sleep(wait)
        return wait

    def _refill(self) -> None:
        now = self._clock()
        elapsed = max(0.0, now - self._updated_at)
        self._updated_at = now
        self._tokens = min(self._capacity, self._tokens + elapsed * self._rate)


DEFAULT_TOTAL_MAX_ATTEMPTS = 5
#: Segundos para abrir la conexión con el plano de control y segundos de
#: espera de cada respuesta (botocore `Config`); paridad con
#: `CONNECTION_TIMEOUT_MS`/`REQUEST_TIMEOUT_MS` de `src/aws/control-plane.ts`.
CONNECT_TIMEOUT_SECONDS: Final = 5
READ_TIMEOUT_SECONDS: Final = 60


@dataclass(frozen=True)
class ClientSettings:
    """Opciones del cliente boto3 que el shim de E2B expone como `retries=`,
    `proxy=` y `ConnectionConfig.set_integration`: `retries` son reintentos
    (intentos totales = `retries + 1`), `proxy` una URL `http://` para
    botocore (nunca en el `repr`) e `integration` un sufijo del User-Agent.
    Es hashable: cada combinación distinta tiene su propio plano compartido."""

    retries: int | None = None
    proxy: str | None = field(default=None, repr=False)
    integration: str | None = None


def client_config(settings: ClientSettings | None = None) -> Config:
    resolved = settings or ClientSettings()
    attempts = DEFAULT_TOTAL_MAX_ATTEMPTS if resolved.retries is None else resolved.retries + 1
    user_agent = f"rayito/{__version__}"
    if resolved.integration:
        user_agent = f"{user_agent} {resolved.integration}"
    proxies = None if resolved.proxy is None else {"http": resolved.proxy, "https": resolved.proxy}
    return Config(
        retries={"mode": "standard", "total_max_attempts": attempts},
        connect_timeout=CONNECT_TIMEOUT_SECONDS,
        read_timeout=READ_TIMEOUT_SECONDS,
        user_agent_extra=user_agent,
        proxies=proxies,
    )


def aws_code(exc: BaseException) -> str | None:
    """El `Error.Code` de un `ClientError` de botocore, o `None` si `exc` no
    trae una respuesta de AWS (`BotoCoreError`, errores de red)."""
    response = getattr(exc, "response", None)
    if not isinstance(response, dict):
        return None
    error = response.get("Error")
    code = error.get("Code") if isinstance(error, dict) else None
    return code if isinstance(code, str) else None


class LazyClient:
    """Un cliente boto3 de `service` que se construye en el primer `get()` (y
    sólo una vez, aunque lo pidan varios hilos), con la sesión dada o una
    sesión de `aws_session` (región según `_aws_region`) y la `client_config()` del SDK. Construirlo
    no hace ninguna llamada a AWS: es lo que usan las funciones opcionales
    (`SecretStore`, `DynamoDbIndex`) para no costar nada mientras no se usan."""

    def __init__(
        self, service: str, *, region: str | None, session: boto3.session.Session | None
    ) -> None:
        self._service = service
        self._region = region
        self._session = session
        self._client: Any | None = None
        self._lock = threading.Lock()

    def get(self) -> Any:
        with self._lock:
            if self._client is None:
                session = aws_session(self._session, self._region)
                self._client = session.client(
                    self._service,
                    region_name=resolve_region(self._region, self._session),
                    config=client_config(),
                )
            return self._client


def control_plane_session(plane: object) -> boto3.session.Session | None:
    """La sesión boto3 de un plano que la expone (`session`), para que el SDK
    firme sus URLs de S3 con el mismo principal que el plano de control
    aunque el llamante sólo pasara `control_plane=`; `None` en cualquier otro
    plano (fakes, envoltorios)."""
    session = getattr(plane, "session", None)
    return session if isinstance(session, boto3.session.Session) else None


class LambdaMicrovmsControlPlane:
    """Adaptador boto3 del puerto `ControlPlane`. Testable con `botocore.stub.Stubber`."""

    def __init__(
        self,
        client: Any,
        *,
        sts_client: Any | None = None,
        sts_client_factory: Callable[[], Any] | None = None,
        clock: MonotonicClock = time.monotonic,
        sleep: Sleeper = time.sleep,
        session: boto3.session.Session | None = None,
    ) -> None:
        self._client = client
        self._sts_client = sts_client
        self._sts_client_factory = sts_client_factory
        self._session = session
        self._buckets = {
            operation: TokenBucket(rate, clock=clock, sleep=sleep)
            for operation, rate in API_TPS.items()
        }
        self._caller_identity: dict[str, str] | None = None
        self._identity_lock = threading.Lock()

    @classmethod
    def from_session(
        cls,
        session: boto3.session.Session | None = None,
        *,
        region: str | None = None,
        settings: ClientSettings | None = None,
    ) -> LambdaMicrovmsControlPlane:
        """El cliente STS se construye sólo si algún template se resuelve por
        nombre; ambos clientes llevan la `client_config(settings)`."""
        resolved_session = aws_session(session, region)
        region = resolve_region(region, session)
        config = client_config(settings)
        return cls(
            resolved_session.client("lambda-microvms", region_name=region, config=config),
            sts_client_factory=lambda: resolved_session.client(
                "sts", region_name=region, config=config
            ),
            session=resolved_session,
        )

    @property
    def session(self) -> boto3.session.Session | None:
        """La sesión boto3 con la que se construyó el plano (`from_session`),
        o `None` si se construyó sobre un cliente suelto."""
        return self._session

    @property
    def region(self) -> str:
        return str(self._client.meta.region_name)

    def resolve_template_arn(self, template: str) -> str:
        """Un nombre pelado no vale en ninguna operación: siempre se pasa el ARN."""
        if template.startswith("arn:"):
            return template
        if not IMAGE_NAME_PATTERN.match(template):
            raise InvalidArgumentException(
                f"template inválido: {template!r} (ARN o nombre [a-zA-Z0-9-_], máx. 64)"
            )
        identity = self._identity()
        partition = identity["Arn"].split(":")[1]
        return (
            f"arn:{partition}:lambda:{self.region}:{identity['Account']}:microvm-image:{template}"
        )

    def run_microvm(self, request: LaunchRequest) -> SandboxInfo:
        """Un `ResourceNotFoundException` aquí es casi siempre una imagen
        ausente: se relanza como el mismo `SandboxNotFoundException`, con
        `status_code`, `aws_code` y causa sanitizada intactos, y el mensaje
        apuntando a `rayito setup` (ADR-030)."""
        try:
            response = self._invoke("RunMicrovm", self._client.run_microvm, **request.to_api())
        except SandboxNotFoundException as exc:
            hinted = SandboxNotFoundException(
                with_setup_hint(str(exc)), status_code=exc.status_code, aws_code=exc.aws_code
            )
            cause = exc.__cause__
        else:
            return sandbox_info_from_response(response)
        raise hinted from cause

    def get_microvm(self, sandbox_id: str) -> SandboxInfo:
        response = self._invoke(
            "GetMicrovm", self._client.get_microvm, microvmIdentifier=sandbox_id
        )
        return sandbox_info_from_response(response)

    def list_microvms(
        self,
        *,
        image_arn: str | None = None,
        image_version: str | None = None,
        states: Iterable[str] | None = None,
    ) -> Iterator[SandboxListItem]:
        """Pagina `list-microvms`; sin `states` omite `TERMINATING|TERMINATED`."""
        params: dict[str, Any] = {"PaginationConfig": {"PageSize": LIST_MAX_RESULTS}}
        if image_arn is not None:
            params["imageIdentifier"] = image_arn
        if image_version is not None:
            params["imageVersion"] = image_version
        wanted = frozenset(states) if states is not None else None
        paginator = self._client.get_paginator("list_microvms")
        try:
            for page in paginator.paginate(**params):
                for item in page.get("items", []):
                    if _listed_state_wanted(item["state"], wanted):
                        yield sandbox_list_item_from_response(item)
            return
        except ClientError as exc:
            translated, cause = sanitized_client_error(exc)
        raise translated from cause

    def list_microvms_page(
        self,
        *,
        image_arn: str | None,
        image_version: str | None,
        max_results: int,
        next_token: str | None,
    ) -> MicrovmListPage:
        """Una sola llamada a `list-microvms` (`maxResults`, y `nextToken`,
        `imageIdentifier`, `imageVersion` sólo si vienen). No filtra por
        estado: eso lo hace el paginador, que así puede reanudar por
        identidad dentro de la página."""
        if not 1 <= max_results <= LIST_MAX_RESULTS:
            raise ValueError(f"max_results fuera de 1-{LIST_MAX_RESULTS}: {max_results}")
        optional = {
            key: value
            for key, value in (
                ("nextToken", next_token),
                ("imageIdentifier", image_arn),
                ("imageVersion", image_version),
            )
            if value is not None
        }
        response = self._invoke(
            "ListMicrovms", self._client.list_microvms, maxResults=max_results, **optional
        )
        items = tuple(sandbox_list_item_from_response(item) for item in response.get("items", []))
        return MicrovmListPage(items=items, next_token=response.get("nextToken"))

    def terminate_microvm(self, sandbox_id: str) -> bool:
        """Idempotente en el modelo; False sólo si el MicroVM no existe."""
        try:
            self._invoke(
                "TerminateMicrovm", self._client.terminate_microvm, microvmIdentifier=sandbox_id
            )
        except SandboxNotFoundException:
            return False
        return True

    def suspend_microvm(self, sandbox_id: str) -> bool:
        """False cuando AWS responde `ConflictException` (no estaba `RUNNING`)."""
        try:
            self._invoke(
                "SuspendMicrovm", self._client.suspend_microvm, microvmIdentifier=sandbox_id
            )
        except SandboxStateException:
            return False
        return True

    def resume_microvm(self, sandbox_id: str) -> bool:
        """False cuando AWS responde `ConflictException` (no estaba `SUSPENDED`)."""
        try:
            self._invoke("ResumeMicrovm", self._client.resume_microvm, microvmIdentifier=sandbox_id)
        except SandboxStateException:
            return False
        return True

    def create_auth_token(self, sandbox_id: str, ports: Sequence[PortSpec]) -> str:
        if not ports:
            raise InvalidArgumentException("allowedPorts necesita al menos un puerto")
        response = self._invoke(
            "CreateMicrovmAuthToken",
            self._client.create_microvm_auth_token,
            microvmIdentifier=sandbox_id,
            expirationInMinutes=TOKEN_TTL_MINUTES,
            allowedPorts=[spec.to_api() for spec in ports],
        )
        return proxy_jwe_from_response(response["authToken"])

    def get_microvm_image_version(self, image_arn: str, image_version: str) -> ImageVersionInfo:
        """Sin cuota propia en `apiTps` (CloudTrail-only, AWS_API_NOTES.md
        §6/§24): `sizes-catalog.ConventionCatalog` es la única llamante y ya
        la cachea por `(image_arn, image_version)`, así que no hace falta un
        `TokenBucket` aquí."""
        response = self._invoke(
            "GetMicrovmImageVersion",
            self._client.get_microvm_image_version,
            imageIdentifier=image_arn,
            imageVersion=image_version,
        )
        resources = response.get("resources") or []
        if not resources:
            raise SandboxException(
                f"la versión {image_version} de {image_arn} no declara "
                "resources[].minimumMemoryInMiB"
            )
        return ImageVersionInfo(minimum_memory_mib=int(resources[0]["minimumMemoryInMiB"]))

    def _invoke(
        self, operation: str, method: Callable[..., dict[str, Any]], **params: Any
    ) -> dict[str, Any]:
        bucket = self._buckets.get(operation)
        if bucket is not None:
            bucket.acquire()
        try:
            return method(**params)
        except ClientError as exc:
            translated, cause = sanitized_client_error(exc)
        raise translated from cause

    def _identity(self) -> dict[str, str]:
        with self._identity_lock:
            if self._caller_identity is None:
                response = self._fetch_caller_identity()
                self._caller_identity = {"Account": response["Account"], "Arn": response["Arn"]}
            return self._caller_identity

    def _fetch_caller_identity(self) -> Any:
        try:
            return self._sts().get_caller_identity()
        except ClientError as exc:
            translated, cause = sanitized_client_error(exc)
        raise translated from cause

    def _sts(self) -> Any:
        if self._sts_client is None and self._sts_client_factory is not None:
            self._sts_client = self._sts_client_factory()
        if self._sts_client is None:
            raise InvalidArgumentException(
                "resolver un template por nombre requiere STS; pasa el ARN de la imagen"
            )
        return self._sts_client


ControlPlaneKey = tuple[Any, str | None, ClientSettings | None]

_shared_planes: dict[ControlPlaneKey, LambdaMicrovmsControlPlane] = {}
_shared_planes_lock = threading.Lock()


def shared_control_plane(
    session: boto3.session.Session | None = None,
    *,
    region: str | None = None,
    settings: ClientSettings | None = None,
) -> LambdaMicrovmsControlPlane:
    """Un plano por `(session, region, settings)` y proceso (ARCHITECTURE.md,
    "Token buckets por proceso"): N `Sandbox.create()` concurrentes con las
    mismas opciones y sin `control_plane` explícito comparten los mismos
    buckets y el mismo cliente boto3.

    La sesión es la clave (no su `id()`) para que el registro la mantenga viva
    y un id reciclado nunca devuelva el plano de otra sesión.
    """
    key: ControlPlaneKey = (session, region, settings)
    with _shared_planes_lock:
        plane = _shared_planes.get(key)
        if plane is None:
            plane = LambdaMicrovmsControlPlane.from_session(
                session, region=region, settings=settings
            )
            _shared_planes[key] = plane
        return plane


def idle_policy_to_api(idle: IdlePolicy) -> dict[str, Any]:
    if idle.suspended_duration_seconds is None:
        raise InvalidArgumentException(
            "suspended_duration_seconds debe estar resuelto antes de run-microvm"
        )
    return {
        "maxIdleDurationSeconds": idle.max_idle_seconds,
        "suspendedDurationSeconds": idle.suspended_duration_seconds,
        "autoResumeEnabled": idle.auto_resume,
    }


def idle_policy_from_response(payload: dict[str, Any] | None) -> IdlePolicy | None:
    if not payload:
        return None
    return IdlePolicy(
        max_idle_seconds=int(payload["maxIdleDurationSeconds"]),
        suspended_duration_seconds=int(payload["suspendedDurationSeconds"]),
        auto_resume=bool(payload["autoResumeEnabled"]),
    )


def normalize_endpoint(endpoint: str) -> str:
    """`endpoint` llega como hostname pelado (medido); tolera `https://host/`."""
    host = endpoint.strip()
    if "://" in host:
        host = host.split("://", 1)[1]
    return host.split("/", 1)[0]


def sandbox_info_from_response(response: dict[str, Any]) -> SandboxInfo:
    return SandboxInfo(
        sandbox_id=response["microvmId"],
        state=response["state"],
        endpoint=normalize_endpoint(response["endpoint"]),
        template=response["imageArn"],
        template_version=response["imageVersion"],
        started_at=response["startedAt"],
        maximum_duration_seconds=int(response["maximumDurationInSeconds"]),
        terminated_at=response.get("terminatedAt"),
        state_reason=response.get("stateReason"),
        idle=idle_policy_from_response(response.get("idlePolicy")),
        execution_role_arn=response.get("executionRoleArn"),
        ingress=tuple(str(arn) for arn in response.get("ingressNetworkConnectors", ())),
        egress=tuple(str(arn) for arn in response.get("egressNetworkConnectors", ())),
    )


def sandbox_list_item_from_response(item: dict[str, Any]) -> SandboxListItem:
    return SandboxListItem(
        sandbox_id=item["microvmId"],
        state=item["state"],
        template=item["imageArn"],
        template_version=item["imageVersion"],
        started_at=item["startedAt"],
    )


def proxy_jwe_from_response(parts: dict[str, str]) -> str:
    """El map trae una única clave `X-aws-proxy-auth` (medido); se toleran otras."""
    exact = parts.get(AUTH_TOKEN_RESPONSE_KEY)
    if exact:
        return exact
    for key, value in parts.items():
        if key.lower() == AUTH_TOKEN_RESPONSE_KEY.lower():
            return value
    if len(parts) == 1:
        return next(iter(parts.values()))
    raise SandboxException(
        f"authToken sin {AUTH_TOKEN_RESPONSE_KEY}; claves recibidas: {sorted(parts)}"
    )


def sanitized_client_error(exc: ClientError) -> tuple[Exception, AwsErrorSummary]:
    """La excepción propia y el resumen seguro que va en su `__cause__`. El
    caller la lanza fuera del `except` (`raise translated from cause`): así
    ni `__cause__` ni `__context__` guardan el `ClientError`, cuyo
    `response` puede repetir la firma y el token de sesión."""
    return translate_client_error(exc), sanitize_aws_error(exc)


def translate_client_error(exc: ClientError) -> Exception:
    """Tabla por `Code`; el mensaje pasa por `redact_aws_text` (un
    `InvalidSignatureException` trae la cadena canónica con el token)."""
    error = exc.response.get("Error", {})
    code = str(error.get("Code", ""))
    message = redact_aws_text(str(error.get("Message") or exc))
    status = exc.response.get("ResponseMetadata", {}).get("HTTPStatusCode")
    if code == "ResourceNotFoundException":
        return SandboxNotFoundException(message, status_code=status, aws_code=code)
    if code == "ValidationException":
        return InvalidArgumentException(message, status_code=status, aws_code=code)
    if code == "AccessDeniedException":
        return AuthenticationException(message, aws_code=code)
    if code == "ThrottlingException":
        retry_after = exc.response.get("retryAfterSeconds")
        return RateLimitException(
            message,
            retry_after=float(retry_after) if retry_after is not None else None,
            status_code=status,
            aws_code=code,
        )
    if code == "ConflictException":
        return SandboxStateException(message, status_code=status, aws_code=code)
    if code == "ServiceQuotaExceededException":
        return QuotaExceededException(message, quota_code=exc.response.get("quotaCode"))
    if code == "InsufficientCapacityException":
        return CapacityException(message)
    return SandboxException(message, status_code=status, aws_code=code or None)


def _listed_state_wanted(state: str, wanted: frozenset[str] | None) -> bool:
    if wanted is None:
        return state not in TERMINAL_STATES
    return state in wanted
