"""Versión del paquete; la lee `pyproject.toml` a través de `uv_build` y el
`user_agent_extra` del cliente boto3."""

from __future__ import annotations

__version__ = "0.15.0"  # x-release-please-version
